﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace PasswordManager
{
    /// <summary>
    /// Interakční logika pro PridatZaznam.xaml
    /// </summary>
    public partial class PridatZaznam : Window
    {
        private static string cesta = $@"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\PasswordManager";
        public PridatZaznam()
        {
            InitializeComponent();
        }

        private string OtoceniStringu(string str)
        {
            char[] pole = str.ToCharArray();
            Array.Reverse(pole);
            return new string(pole);
        }

        private void PridejHeslobtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(Heslo.Text.Length > 0 && Sluzba.Text.Length > 0)
                {
                    File.AppendAllText(cesta + "\\zaznamy.txt", $"{OtoceniStringu(Sluzba.Text)}|{OtoceniStringu(Heslo.Text)}{Environment.NewLine}");
                    Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nastala chyba", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
