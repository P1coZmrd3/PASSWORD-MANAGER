﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace PasswordManager
{
    /// <summary>
    /// Interakční logika pro Aplikace.xaml
    /// </summary>
    public partial class Aplikace : Window
    {
        private static string cesta = $@"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\PasswordManager";

        public Aplikace()
        {
            InitializeComponent();
        }

        private void Aktualizace(string[] zaznamy)
        {
            Zaznamy.ItemsSource = null;
            Zaznamy.ItemsSource = zaznamy;
        }

        private string OtoceniStringu(string str)
        {
            char[] pole = str.ToCharArray();
            Array.Reverse(pole);
            return new string(pole);
        }

        private void PridatZaznam_Click(object sender, RoutedEventArgs e)
        {
            PridatZaznam pridatZaznam = new PridatZaznam();
            pridatZaznam.Show();
        }

        private void SmazatVsechno_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult volbaReset = MessageBox.Show("Chcete smazat všechny záznamy?", "", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if(volbaReset == MessageBoxResult.Yes)
            {
                File.Delete(cesta + "\\zaznamy.txt");
            }

        }

        private void ZmenitHeslo_Click(object sender, RoutedEventArgs e)
        {
            ZmenitHeslo zmenitHeslo = new ZmenitHeslo();
            zmenitHeslo.Show();
        }

        private void Aktualizovat_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (File.Exists(cesta + "\\zaznamy.txt"))
                {
                    string[] zaznamy = File.ReadAllLines(cesta + "\\zaznamy.txt");
                    string[] upraveneZaznamy = new string[zaznamy.Length];
                    for (int i = 0; i < zaznamy.Length; i++)
                    {
                        string[] zaznam = zaznamy[i].Split("|");
                        upraveneZaznamy[i] = OtoceniStringu(zaznam[0]) + " | HESLO: " + OtoceniStringu(zaznam[1]);
                    }
                    Aktualizace(upraveneZaznamy);
                }
                else
                    Aktualizace(new string[] {""});

            }
            catch (Exception)
            {

                MessageBox.Show("Nastala chyba", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
