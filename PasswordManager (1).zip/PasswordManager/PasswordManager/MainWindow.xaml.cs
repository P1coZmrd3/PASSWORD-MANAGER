﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using BCrypt.Net;

namespace PasswordManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static string cesta = $@"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\PasswordManager";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Registracebtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (Heslo.Text.Length > 0)
                {
                    MessageBoxResult volba = MessageBox.Show("Pokud existují nějaké záznamy, všechny budou smazány. Opravdu je chcete smazat?", "Upozornění", MessageBoxButton.YesNo);
                    if (volba == MessageBoxResult.Yes)
                    {
                        if (File.Exists(cesta + "\\zaznamy.txt"))
                            File.Delete(cesta + "\\zaznamy.txt");

                        string zasifrovane = BCrypt.Net.BCrypt.HashPassword(Heslo.Text);
                        Directory.CreateDirectory(cesta);
                        File.WriteAllText(cesta + "\\hash.txt", zasifrovane);
                        Aplikace aplikace = new Aplikace();
                        aplikace.Show();
                        Close();
                    }

                }
                else
                    MessageBox.Show("Heslo je prázdné", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception)
            {

                MessageBox.Show("Nastala chyba", "Chyba", MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void Prihlasenibtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Heslo.Text.Length > 0)
                {

                    if (BCrypt.Net.BCrypt.Verify(Heslo.Text, File.ReadAllText(cesta + "\\hash.txt")))
                    {
                        Aplikace aplikace = new Aplikace();
                        aplikace.Show();
                        Close();
                    }
                    else
                        MessageBox.Show("Hesla nejsou stejná", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Nastala chyba", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
