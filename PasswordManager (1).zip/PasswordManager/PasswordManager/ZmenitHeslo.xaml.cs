﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace PasswordManager
{
    /// <summary>
    /// Interakční logika pro ZmenitHeslo.xaml
    /// </summary>
    public partial class ZmenitHeslo : Window
    {
        private static string cesta = $@"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\PasswordManager";
        public ZmenitHeslo()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (NoveHeslo.Text.Length > 0 && StareHeslo.Text.Length > 0)
                {

                    if (BCrypt.Net.BCrypt.Verify(StareHeslo.Text, File.ReadAllText(cesta + "\\hash.txt")))
                    {
                        string zasifrovane = BCrypt.Net.BCrypt.HashPassword(NoveHeslo.Text);
                        File.WriteAllText(cesta + "\\hash.txt", zasifrovane);
                        MessageBox.Show("Heslo bylo změněno","",MessageBoxButton.OK);
                        Close();
                    }
                    else
                        MessageBox.Show("Hesla nejsou stejná", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);


                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nastala chyba", "Chyba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
